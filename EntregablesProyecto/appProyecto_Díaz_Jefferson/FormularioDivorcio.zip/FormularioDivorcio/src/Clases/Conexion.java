/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.sql.*;

/**
 *
 * @author Omar
 */
public class Conexion {

//    public Conexion() {
//    }
    static Connection contacto = null;

    public static Connection getConnection() {
        final String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
        final String DRIVER = "org.postgresql.Driver";
        final String USUARIO = "postgres";
        final String CLAVE = "12345";
        Conexion con;

        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            System.out.println("No es puedo establecer la conexion: " + e.getMessage());
        }
        try {
            contacto = DriverManager.getConnection(URL, USUARIO, CLAVE);
//                String sql = ""
        } catch (Exception e) {
            System.out.println("No es puedo establecer la conexion: " + e.getMessage());
        }
        return contacto;
    }

}
