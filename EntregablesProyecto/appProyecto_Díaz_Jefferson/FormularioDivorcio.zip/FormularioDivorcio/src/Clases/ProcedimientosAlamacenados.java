/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Omar
 */
public class ProcedimientosAlamacenados {
//    Connection cn;
//    CallableStatement cs;
//    String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
//    String CLAVE = "12345";
//    try{
//    Class.forName("org.postgresql.Driver");
//    cn = DriverManager.getConnection(URL,"postgres" ,CLAVE);
//}catch(Exception e){
//    
//}
    public static void insertarDatosDivorcio1(String a, String b, String c, String d, String e) throws SQLException{
        CallableStatement registro = Conexion.getConnection().prepareCall("call INSERTAR_DATO_DIVORCIO(?,?,?,?,?)");
        registro.setString(1, a);
        registro.setString(2, b);
        registro.setString(3, c);
        registro.setString(4, d);
        registro.setString(5, e);
        registro.execute();
        
    }
}
