/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ventanas;

import Clases.Conexion;
import Clases.ProcedimientosAlamacenados;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class JF_FormularioDivorcio extends javax.swing.JFrame {

    private Connection connection = null;
    private ResultSet rs = null;
    private Statement s = null;

    public JF_FormularioDivorcio() {
//        this.setLocationRelativeTo(null);
        this.setTitle("FORMULARIO DIVORCIOS");
        /*estas dos lineas son para cambiar el icono al programa*/
        Image icono = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource(("imagenes/registrocivil.PNG")));
        this.setIconImage(icono);
        initComponents();
        Conexion();
        llenarCmbProvincias();
        llenarCmbEtnias();
        llenarCmbNivelInstruccion();
        llenarCmbCausasDivorcio();
    }

    public void Conexion() {

        if (connection != null) {
            return;
        }
        String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
        String CLAVE = "12345";
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(URL, "postgres", CLAVE);

            if (connection != null) {
                System.out.println("Conectado a la base de datos");
            }
        } catch (SQLException e) {
            System.out.println("problemas al conectar la base de datos");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JF_FormularioDivorcio.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void GuardarUsuario(String fechamatrimonio, String bienes, String duracionmatrimonio, String causa) {

        String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
        String CLAVE = "12345";
        try {
            Class.forName("org.postgresql.Driver");
            Connection conne = (Connection) DriverManager.getConnection(URL, "postgres", CLAVE);
            Statement consulta = (Statement) conne.createStatement();
            consulta.executeUpdate("insert into datos_divorcio(fechamatrimonio, bienes, duracionmatrimonio, causa) values('" + fechamatrimonio + "','" + bienes
                    + "','" + duracionmatrimonio + "','" + causa + "')");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El error es: " + e);

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error inesperado");
        }
    }

    public void GuardarNAcionalidad(String nacion, String paisNacimi, String codPais) {
        String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
        String CLAVE = "12345";
        try {
            Class.forName("org.postgresql.Driver");
            Connection conne = (Connection) DriverManager.getConnection(URL, "postgres", CLAVE);
            Statement consulta = (Statement) conne.createStatement();
            consulta.executeUpdate("insert into nacionalidad(nacion, paisnaci, codpaidnaci) values('" + nacion + "','" + paisNacimi
                    + "','" + codPais + "')");
            System.out.println("Nacionalidad Registrada");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El error es: " + e);

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error inesperado");
        }
    }

    public void GuardarUbicacion(String provincia, String canton, String localidad) {
        String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
        String CLAVE = "12345";
        try {
            Class.forName("org.postgresql.Driver");
            Connection conne = (Connection) DriverManager.getConnection(URL, "postgres", CLAVE);
            Statement consulta = (Statement) conne.createStatement();
            consulta.executeUpdate("insert into ubicacion(provinvia, parroquia, localidad) values('" + provincia + "','" + canton
                    + "','" + localidad + "')");
            System.out.println("Ubicacion Registrada");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El error es: " + e);

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error inesperado");
        }
    }

    public void guardarDatosPersonales(String idInstruc, String idNacionalidad, String autoidentifi, String ideUbica,
            String cedulaPersona, String fechaNaciPer, String edad, String hijosCargo, String genero, String DPAper, String localPerson, String nombPer) {
        String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
        String CLAVE = "12345";
        try {
            Class.forName("org.postgresql.Driver");
            Connection conne = (Connection) DriverManager.getConnection(URL, "postgres", CLAVE);
            Statement consulta = (Statement) conne.createStatement();
            consulta.executeUpdate("insert into datos_personales(idinstrc, idnacionalidad, idautoidentificacion,"
                    + "idubicacion, cedulaperso, fechanaciperso, edad,"
                    + "hijoscargoper,generoperso,dpaperso,localperso, nombrePer) values('" + idInstruc + "','" + idNacionalidad
                    + "','" + autoidentifi + "','" + ideUbica + "','" + cedulaPersona + "','" + fechaNaciPer
                    + "','" + edad + "','" + hijosCargo + "','" + genero + "','" + DPAper + "','" + localPerson + "','" + nombPer + "')");
            System.out.println("DATOS PERSONALES REGISTRADOS .....................");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El error es: " + e);

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error inesperado");
        }
    }

    public void llenarFormulario(String idUbicacion, String idMatrimonio, String idDatosPersonales, String OfiFormula, String fechInsCripFormu,
            String necFormu, String numOficioFor, String actaInscripcionform, String FechaSentenciaFor, String nombFuncionarioForm,
            String cedulaFuncion, String observacion, String codCriticoCodificador) {
        String URL = "jdbc:postgresql://localhost:5432/FormularioDivorcio";
        String CLAVE = "12345";
        try {
            Class.forName("org.postgresql.Driver");
            Connection conne = (Connection) DriverManager.getConnection(URL, "postgres", CLAVE);
            Statement consulta = (Statement) conne.createStatement();
            consulta.executeUpdate("insert into formulario(idubicacion, idmatrimonio, iddatoperso,"
                    + "oficinaformulario, fechainscripcionfor, necform, numoficioform,"
                    + "actinscripform,fechasentenciaform,nombrefuncionaform,cedulafuncionaform, obserbacionesform,"
                    + "codigocriticocodificador) values('" + idUbicacion + "','" + idMatrimonio
                    + "','" + idDatosPersonales + "','" + OfiFormula + "','" + fechInsCripFormu + "','" + necFormu
                    + "','" + numOficioFor + "','" + actaInscripcionform + "','" + FechaSentenciaFor + "','" + nombFuncionarioForm
                    + "','" + cedulaFuncion + "','" + observacion + "','" + codCriticoCodificador + "')");
            JOptionPane.showMessageDialog(this,"........................FORMULARIO REGISTRADO CON EXITO....................." );
            System.out.println("........................FORMULARIO REGISTRADO .....................");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "El error es: " + e);

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error inesperado");
        }
    }

    public void llenarCmbCausasDivorcio() {
        Conexion();

        try {
            s = connection.createStatement();
            rs = s.executeQuery("SELECT descripcausa FROM public.causadivorcio");
            System.out.println("llenando causas divorcio");
        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String cusas = "";
        try {
            while (rs.next()) {
                cusas = rs.getString(1);
                cmbCausa.addItem(cusas);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo provincias");
        }

    }

    public void llenarCmbNivelInstruccion() {
        Conexion();

        try {
            s = connection.createStatement();
            rs = s.executeQuery("select nivelinstruc from nivel_instruccion");
            System.out.println("llenando el combo instruccion");
        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String instruccion = "";
        try {
            while (rs.next()) {
                instruccion = rs.getString(1);
                cmbNivelInstruccion.addItem(instruccion);
                cmbNivelInstruccionM.addItem(instruccion);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo instruccion");
        }
    }

    public void llenarCmbEtnias() {
        Conexion();

        try {
            s = connection.createStatement();
            rs = s.executeQuery("select etnia from autoedintificacion");
            System.out.println("llenando el combo etnia");
        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String etnias = "";
        try {
            while (rs.next()) {
                etnias = rs.getString(1);
                cmbEtnia.addItem(etnias);
                cmbEtniaM.addItem(etnias);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo provincias");
        }
    }

    public void llenarCmbProvincias() {
        Conexion();

        try {
            s = connection.createStatement();
            rs = s.executeQuery("select nombprovincia from provincia");
            System.out.println("llenando el combo provincias");
        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String provincias = "";
        try {
            while (rs.next()) {
                provincias = rs.getString(1);
                CmbProvincias.addItem(provincias);
                cmbProvinciaDivorciado.addItem(provincias);
                cmbProvinciaDivorciada.addItem(provincias);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo provincias");
        }

//          cargando el numero de formulario   
String numeroFormulario="";
int numF=0;
        try {
            s = connection.createStatement();
            rs = s.executeQuery("select max(idformulario) from formulario;");
            System.out.println("---------------Obteniendo el numero de formulario");
        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos para el numero de formulario: "
                    + " tipo de error: " + e);
        }
        try {
            while (rs.next()) {
                numeroFormulario = rs.getString(1);
                System.out.println("*************** EL unmero de formulario es :" + numeroFormulario+"r");
                
        numF =Integer.parseInt(numeroFormulario)+1;
        lblNumFormulario.setText(numF+"");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al tratar de cargar el numero de formulario");
        }
//          final de la carga de datos de nuemro de formulario

    }

    public void llenarCmbCantones() {
        Conexion();
        CmbCantones.removeAllItems();
//        cmbCantonDivorciado.removeAllItems();
        System.out.println("Se estan cargando los datos en relacion a :" + CmbProvincias.getSelectedItem());
        try {
            s = connection.createStatement();
            rs = s.executeQuery("select nombcanton from canton,provincia where provincia.idprovincia = canton.idprovincia and\n"
                    + "	provincia.nombprovincia ='" + CmbProvincias.getSelectedItem() + "'");
            System.out.println("llenando el combo cantones");
            cmbParroquia.removeAllItems();

        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String cantones = "";
        try {
            while (rs.next()) {
                cantones = rs.getString(1);
                CmbCantones.addItem(cantones);
//                cmbCantonDivorciado.addItem(cantones);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo cantones");
        }
    }

    public void llenarCmbCantonesDivorciado() {
        Conexion();
        cmbCantonDivorciado.removeAllItems();
        System.out.println("Se estan cargando los datos en relacion a :" + CmbProvincias.getSelectedItem());
        try {
            s = connection.createStatement();
            rs = s.executeQuery("select nombcanton from canton,provincia where provincia.idprovincia = canton.idprovincia and\n"
                    + "	provincia.nombprovincia ='" + cmbProvinciaDivorciado.getSelectedItem() + "'");
            System.out.println("llenando el combo cantones");
            cmbParroquia.removeAllItems();

        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String cantones = "";
        try {
            while (rs.next()) {
                cantones = rs.getString(1);
                cmbCantonDivorciado.addItem(cantones);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo cantones");
        }
    }

    public void llenarCmbCantonesDivorciada() {
        Conexion();
        cmbCantonDivorciada.removeAllItems();
        System.out.println("Se estan cargando los datos en relacion a :" + cmbProvinciaDivorciada.getSelectedItem());
        try {
            s = connection.createStatement();
            rs = s.executeQuery("select nombcanton from canton,provincia where provincia.idprovincia = canton.idprovincia and\n"
                    + "	provincia.nombprovincia ='" + cmbProvinciaDivorciada.getSelectedItem() + "'");
            System.out.println("llenando el combo cantones");
            cmbParroquiaDivorciada.removeAllItems();

        } catch (Exception e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String cantones = "";
        try {
            while (rs.next()) {
                cantones = rs.getString(1);
                cmbCantonDivorciada.addItem(cantones);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo cantones");
        }
    }

    public void llenarCmbParroquias() {
        Conexion();
        cmbParroquia.removeAllItems();
        try {
            System.out.println("Se estan cargando los datos del canton :" + CmbCantones.getSelectedItem());
            s = connection.createStatement();
            rs = s.executeQuery("select nombparroquia from parroquiaurbanarural,canton where canton.idcanton = parroquiaurbanarural.idcanton and\n"
                    + "	canton.nombcanton = '" + CmbCantones.getSelectedItem() + "'");
            System.out.println("llenando el combo parroquias");
        } catch (SQLException e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String cantones = "";
        try {
            while (rs.next()) {
                cantones = rs.getString(1);
                cmbParroquia.addItem(cantones);
                cmbParroquiaDivorciado.addItem(cantones);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo parroquias");
        }
    }

    public void llenarCmbParroquiasDivorciado() {
        Conexion();
        cmbParroquiaDivorciado.removeAllItems();
        try {
            System.out.println("Se estan cargando los datos del canton :" + cmbCantonDivorciado.getSelectedItem());
            s = connection.createStatement();
            rs = s.executeQuery("select nombparroquia from parroquiaurbanarural,canton where canton.idcanton = parroquiaurbanarural.idcanton and\n"
                    + "	canton.nombcanton = '" + cmbCantonDivorciado.getSelectedItem() + "'");
            System.out.println("llenando el combo parroquias");
        } catch (SQLException e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String cantones = "";
        try {
            while (rs.next()) {
                cantones = rs.getString(1);
                cmbParroquiaDivorciado.addItem(cantones);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo parroquias");
        }
    }

    public void llenarCmbParroquiasDivorciada() {
        Conexion();
        cmbParroquiaDivorciada.removeAllItems();
        try {
            System.out.println("Se estan cargando los datos del canton :" + cmbCantonDivorciada.getSelectedItem());
            s = connection.createStatement();
            rs = s.executeQuery("select nombparroquia from parroquiaurbanarural,canton where canton.idcanton = parroquiaurbanarural.idcanton and\n"
                    + "	canton.nombcanton = '" + cmbCantonDivorciada.getSelectedItem() + "'");
            System.out.println("llenando el combo parroquias");
        } catch (SQLException e) {
            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
                    + " tipo de error: " + e);
        }
        String cantones = "";
        try {
            while (rs.next()) {
                cantones = rs.getString(1);
                cmbParroquiaDivorciada.addItem(cantones);
            }
        } catch (Exception e) {
            System.out.println("No se puede llenar el combo parroquias");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupBienes = new javax.swing.ButtonGroup();
        buttonGroupNacionalidad = new javax.swing.ButtonGroup();
        buttonGroupLeerEscribir = new javax.swing.ButtonGroup();
        buttonGroupNAcionalidadM = new javax.swing.ButtonGroup();
        buttonGroupLeerEscribirM = new javax.swing.ButtonGroup();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblLogo = new javax.swing.JLabel();
        lblLogoRegistroCivil = new javax.swing.JLabel();
        lblNumFormulario = new javax.swing.JLabel();
        panel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtnombOfiRC = new javax.swing.JTextField();
        CmbProvincias = new javax.swing.JComboBox<>();
        CmbCantones = new javax.swing.JComboBox<>();
        cmbParroquia = new javax.swing.JComboBox<>();
        anioInscricion = new com.toedter.calendar.JYearChooser();
        mesInscripcion = new com.toedter.calendar.JMonthChooser();
        jSpinnerFechaInscripcion = new javax.swing.JSpinner();
        jLabel83 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        txtInecForm = new javax.swing.JTextField();
        txtNunOficina = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtActaInscripcion = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        FechaSentencia = new javax.swing.JSpinner();
        MesSentencia = new com.toedter.calendar.JMonthChooser();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        anioSentencia = new com.toedter.calendar.JYearChooser();
        panel2 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jRadioButtonSiBienes = new javax.swing.JRadioButton();
        jRadioButtonNoBienes = new javax.swing.JRadioButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        anioMatrimonio = new com.toedter.calendar.JYearChooser();
        mesMatrimonio = new com.toedter.calendar.JMonthChooser();
        FechaMatrimonio = new javax.swing.JSpinner();
        jSpinnerAniosMatrimonio = new javax.swing.JSpinner();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        panel6 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        cmbCausa = new javax.swing.JComboBox<>();
        panel3 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        txtNombDivorciado = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jRadioButtonEcuatorianoH = new javax.swing.JRadioButton();
        jRadioButtonExtranjeroH = new javax.swing.JRadioButton();
        txtNombrePaisH = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        txtCodPaisH = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        panel4 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        txtCedulaDivorciado = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        anioNacimientoDivorciado = new com.toedter.calendar.JYearChooser();
        mesNacimientoDivorciado = new com.toedter.calendar.JMonthChooser();
        FechaNacimientoDivorciado = new javax.swing.JSpinner();
        jLabel101 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jSpinnerEdadDivorciado = new javax.swing.JSpinner();
        jPanel15 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jSpinnernumeroHijoDivorciado = new javax.swing.JSpinner();
        jPanel16 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        cmbEtnia = new javax.swing.JComboBox<>();
        jPanel17 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jRadioButtonLeerEscribirSI = new javax.swing.JRadioButton();
        jRadioButtonLeerEscribirNO = new javax.swing.JRadioButton();
        JpanelNivelEstudios1 = new javax.swing.JPanel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        cmbNivelInstruccion = new javax.swing.JComboBox<>();
        jPanel18 = new javax.swing.JPanel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        cmbProvinciaDivorciado = new javax.swing.JComboBox<>();
        cmbCantonDivorciado = new javax.swing.JComboBox<>();
        cmbParroquiaDivorciado = new javax.swing.JComboBox<>();
        jPanel19 = new javax.swing.JPanel();
        txtDPAHom = new javax.swing.JTextField();
        jLabel71 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        txtLocalidadHom = new javax.swing.JTextField();
        jLabel76 = new javax.swing.JLabel();
        panel5 = new javax.swing.JPanel();
        panel7 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel77 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel78 = new javax.swing.JLabel();
        txtNombDivorciada = new javax.swing.JTextField();
        jLabel79 = new javax.swing.JLabel();
        jRadioButtonEcuatorianoM = new javax.swing.JRadioButton();
        jRadioButtonExtrangeroM = new javax.swing.JRadioButton();
        txtNombrePaisM = new javax.swing.JTextField();
        jLabel80 = new javax.swing.JLabel();
        txtCodPaisM = new javax.swing.JTextField();
        jLabel81 = new javax.swing.JLabel();
        jLabel82 = new javax.swing.JLabel();
        panel9 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel84 = new javax.swing.JLabel();
        txtCedulaDivorciada = new javax.swing.JTextField();
        jPanel26 = new javax.swing.JPanel();
        jLabel85 = new javax.swing.JLabel();
        anioNacimientoDivorciada = new com.toedter.calendar.JYearChooser();
        jLabel107 = new javax.swing.JLabel();
        mesNacimientoDivorciada = new com.toedter.calendar.JMonthChooser();
        jLabel108 = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        FechaNacimientoDivorciada = new javax.swing.JSpinner();
        jPanel27 = new javax.swing.JPanel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jSpinnerEdadDivorciada = new javax.swing.JSpinner();
        jPanel28 = new javax.swing.JPanel();
        jLabel88 = new javax.swing.JLabel();
        jSpinnernumeroHijoDivorciada = new javax.swing.JSpinner();
        jPanel29 = new javax.swing.JPanel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        cmbEtniaM = new javax.swing.JComboBox<>();
        jPanel30 = new javax.swing.JPanel();
        jLabel102 = new javax.swing.JLabel();
        jRadioButtonLeerEscribirSIM = new javax.swing.JRadioButton();
        jRadioButton44 = new javax.swing.JRadioButton();
        JpanelNivelEstudios2 = new javax.swing.JPanel();
        jLabel103 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        cmbNivelInstruccionM = new javax.swing.JComboBox<>();
        jPanel31 = new javax.swing.JPanel();
        jLabel115 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        cmbProvinciaDivorciada = new javax.swing.JComboBox<>();
        cmbCantonDivorciada = new javax.swing.JComboBox<>();
        cmbParroquiaDivorciada = new javax.swing.JComboBox<>();
        jPanel32 = new javax.swing.JPanel();
        txtDPAMujer = new javax.swing.JTextField();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        txtLocalidadMujer = new javax.swing.JTextField();
        jLabel122 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        txtCodCriticoCodifica = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        TxtNombreFuncionarioRC = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        txtCedulaFuncionarioRC = new javax.swing.JTextField();
        jPanel22 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        txtObservaciones = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnAbrirRegistor = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Republica del Ecuador");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("FORMULARIO DE DIVORCIO");

        lblLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LOGO nec.PNG"))); // NOI18N

        lblLogoRegistroCivil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/registrocivil.PNG"))); // NOI18N

        lblNumFormulario.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblNumFormulario.setForeground(new java.awt.Color(255, 0, 0));
        lblNumFormulario.setText("0000000000");
        lblNumFormulario.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblLogo)
                .addGap(96, 96, 96)
                .addComponent(jLabel2)
                .addGap(143, 143, 143)
                .addComponent(jLabel1)
                .addGap(51, 51, 51)
                .addComponent(lblLogoRegistroCivil)
                .addGap(63, 63, 63)
                .addComponent(lblNumFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(137, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLogo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(lblLogoRegistroCivil)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(lblNumFormulario, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(jLabel2)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        panel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel2MouseExited(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("1) OFICINA DE REGISTRO CIVIL DE:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("2) PROVINCIA:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("CANTÓN:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("PARROQUIA URBANA O RURAL:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("3) FECHA DE INSCRIPCIÓN:");

        txtnombOfiRC.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtnombOfiRC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtnombOfiRCKeyReleased(evt);
            }
        });

        CmbProvincias.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                CmbProvinciasItemStateChanged(evt);
            }
        });

        CmbCantones.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CmbCantonesMouseClicked(evt);
            }
        });

        cmbParroquia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbParroquiaMouseClicked(evt);
            }
        });

        jSpinnerFechaInscripcion.setModel(new javax.swing.SpinnerNumberModel(1, 1, 31, 1));

        jLabel83.setText("Año");

        jLabel93.setText("Mes");

        jLabel94.setText("Día");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CmbProvincias, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CmbCantones, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtnombOfiRC, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(27, 27, 27)
                                        .addComponent(jLabel6))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(jLabel83))
                                            .addComponent(anioInscricion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(cmbParroquia, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(mesInscripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(46, 46, 46)
                                                .addComponent(jLabel93)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel2Layout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(jLabel94))
                                            .addComponent(jSpinnerFechaInscripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtnombOfiRC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(CmbProvincias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(CmbCantones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cmbParroquia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(anioInscricion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mesInscripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinnerFechaInscripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel83)
                        .addComponent(jLabel93))
                    .addComponent(jLabel94))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 315, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 112, Short.MAX_VALUE)
        );

        txtInecForm.setBackground(new java.awt.Color(102, 204, 255));
        txtInecForm.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        txtNunOficina.setBackground(new java.awt.Color(102, 204, 255));
        txtNunOficina.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("4) ACTA DE INSCRIPCION:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("5) FECHA DE SENTENCIA:");

        jLabel10.setText("USO INEC");

        jLabel11.setText("Oficina N°");

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        jLabel13.setText("(Debe ser el mismo que conste en el libro de inscripciones)");

        jLabel98.setText("Día");

        FechaSentencia.setModel(new javax.swing.SpinnerNumberModel(1, 1, 31, 1));

        jLabel99.setText("Mes");

        jLabel100.setText("Año");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jLabel9))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                                .addGap(238, 238, 238)
                                .addComponent(jLabel13)))
                        .addGap(0, 83, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel8)
                        .addGap(26, 26, 26)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(jLabel100))
                                    .addComponent(anioSentencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(MesSentencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(46, 46, 46)
                                        .addComponent(jLabel99)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(jLabel98))
                                    .addComponent(FechaSentencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(txtActaInscripcion))))
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                        .addComponent(txtInecForm, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtNunOficina, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel6Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel10)
                        .addGap(82, 82, 82)
                        .addComponent(jLabel11)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addGap(5, 5, 5)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtInecForm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNunOficina, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtActaInscripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(1, 1, 1)
                .addComponent(jLabel13)
                .addGap(9, 9, 9)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(anioSentencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(MesSentencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FechaSentencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel100)
                                .addComponent(jLabel99))
                            .addComponent(jLabel98))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(933, Short.MAX_VALUE)))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        panel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("6) FECHA DEL MATRIMONIO:");

        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setText("7) CUANDO SE CELEBRÓ EL MATRIMONIO");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel16.setText("¿FUÉ CON CAPITULACIÓ DE BIENES?");

        buttonGroupBienes.add(jRadioButtonSiBienes);
        jRadioButtonSiBienes.setText("SI");

        buttonGroupBienes.add(jRadioButtonNoBienes);
        jRadioButtonNoBienes.setText("NO");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15)
                    .addComponent(jLabel16))
                .addGap(24, 24, 24)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButtonSiBienes)
                    .addComponent(jRadioButtonNoBienes))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jRadioButtonSiBienes)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jRadioButtonNoBienes))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel16)))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17.setText("8) DURACIÓN DEL MATRIMONIO:");

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        jLabel18.setText("(años cumplidos)");

        FechaMatrimonio.setModel(new javax.swing.SpinnerNumberModel(1, 1, 31, 1));

        jSpinnerAniosMatrimonio.setModel(new javax.swing.SpinnerNumberModel(0, 0, 70, 1));

        jLabel95.setText("Año");

        jLabel96.setText("Mes");

        jLabel97.setText("Día");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addComponent(anioMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(mesMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel95)
                        .addGap(64, 64, 64)
                        .addComponent(jLabel96)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel97))
                    .addComponent(FechaMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel17)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSpinnerAniosMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(anioMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14)
                            .addComponent(mesMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FechaMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel95)
                            .addComponent(jLabel96)
                            .addComponent(jLabel97)))
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(jSpinnerAniosMatrimonio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel18)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panel6MouseExited(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel19.setText("9) CAUSA DEL DIVORCIO");

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel20.setText("(Marque solo una causa tomando en cuenta la sentencia ejecutoriada)");

        cmbCausa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout panel6Layout = new javax.swing.GroupLayout(panel6);
        panel6.setLayout(panel6Layout);
        panel6Layout.setHorizontalGroup(
            panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel6Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel20)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(panel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel19)
                .addGap(99, 99, 99)
                .addComponent(cmbCausa, javax.swing.GroupLayout.PREFERRED_SIZE, 671, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel6Layout.setVerticalGroup(
            panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(cmbCausa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addComponent(jLabel20)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panel3MouseExited(evt);
            }
        });

        jPanel9.setBackground(new java.awt.Color(153, 153, 153));

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel32.setText("(A) DATOS DEL DIVORCIADO");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(456, 456, 456)
                .addComponent(jLabel32)
                .addContainerGap(591, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel32)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel33.setText("10) NOMBRES Y APELLIDOS");

        txtNombDivorciado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtNombDivorciado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombDivorciadoKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel33)
                    .addComponent(txtNombDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtNombDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel34.setText("11) NACIONALIDAD");

        buttonGroupNacionalidad.add(jRadioButtonEcuatorianoH);
        jRadioButtonEcuatorianoH.setText("Ecuatoriano");
        jRadioButtonEcuatorianoH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonEcuatorianoHActionPerformed(evt);
            }
        });

        buttonGroupNacionalidad.add(jRadioButtonExtranjeroH);
        jRadioButtonExtranjeroH.setText("Extrangero");
        jRadioButtonExtranjeroH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonExtranjeroHActionPerformed(evt);
            }
        });

        txtNombrePaisH.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtNombrePaisH.setEnabled(false);
        txtNombrePaisH.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombrePaisHKeyReleased(evt);
            }
        });

        jLabel35.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel35.setText("Nombre del pais");

        txtCodPaisH.setBackground(new java.awt.Color(102, 204, 255));
        txtCodPaisH.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtCodPaisH.setEnabled(false);
        txtCodPaisH.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodPaisHKeyTyped(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel36.setText("USO INEC");

        jLabel37.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel37.setText("Código del pais");

        javax.swing.GroupLayout panel3Layout = new javax.swing.GroupLayout(panel3);
        panel3.setLayout(panel3Layout);
        panel3Layout.setHorizontalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel3Layout.createSequentialGroup()
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panel3Layout.createSequentialGroup()
                                .addComponent(jRadioButtonEcuatorianoH)
                                .addGap(18, 18, 18)
                                .addComponent(jRadioButtonExtranjeroH)
                                .addGap(32, 32, 32)
                                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNombrePaisH, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel35)))
                            .addComponent(jLabel34))
                        .addGap(67, 67, 67)
                        .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel36)
                            .addComponent(jLabel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtCodPaisH)))
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 5, Short.MAX_VALUE))
        );
        panel3Layout.setVerticalGroup(
            panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel3Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(panel3Layout.createSequentialGroup()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel3Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel34)
                        .addGap(18, 18, 18))
                    .addGroup(panel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel36)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonEcuatorianoH)
                    .addComponent(jRadioButtonExtranjeroH)
                    .addComponent(txtNombrePaisH, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCodPaisH, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel37)))
        );

        panel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panel4MouseExited(evt);
            }
        });

        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel38.setText("11) No. Cédula De Ciudadania o Pasaporte");

        txtCedulaDivorciado.setBackground(new java.awt.Color(102, 204, 255));
        txtCedulaDivorciado.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtCedulaDivorciado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaDivorciadoKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel38, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtCedulaDivorciado, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel38)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCedulaDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel39.setText("12) Fecha de nacimiento");

        FechaNacimientoDivorciado.setModel(new javax.swing.SpinnerNumberModel(1, 1, 31, 1));

        jLabel101.setText("Día");

        jLabel105.setText("Mes");

        jLabel106.setText("Año");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel39))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(anioNacimientoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(mesNacimientoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel106)
                                .addGap(64, 64, 64)
                                .addComponent(jLabel105)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel101))
                            .addComponent(FechaNacimientoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(jLabel39)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(anioNacimientoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mesNacimientoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FechaNacimientoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel106)
                    .addComponent(jLabel105)
                    .addComponent(jLabel101)))
        );

        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel40.setText("13) Edad");

        jLabel41.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel41.setText("Años cumplidos a la fecha de inscripción");

        jSpinnerEdadDivorciado.setModel(new javax.swing.SpinnerNumberModel(16, 16, null, 1));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel40))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel41)
                            .addComponent(jSpinnerEdadDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel40)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel41)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinnerEdadDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel42.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel42.setText("15) Número de hijo a cargo del divorciado");

        jSpinnernumeroHijoDivorciado.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel42))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jSpinnernumeroHijoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSpinnernumeroHijoDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel43.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel43.setText("16) AUTOIDENTIFICACIÓN");

        jLabel44.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel44.setText("ETNIA DEL DIVORCIADO");

        jLabel45.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel45.setText("Según la cultura y constumbres como");

        jLabel46.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel46.setText("se idetifica el divorciado");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbEtnia, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel46)
                            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel43, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel44, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel45, javax.swing.GroupLayout.Alignment.TRAILING)))
                        .addGap(0, 16, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel43)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel44)
                .addGap(1, 1, 1)
                .addComponent(jLabel45)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel46)
                .addGap(43, 43, 43)
                .addComponent(cmbEtnia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel56.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel56.setText("17.1) ¿SABE LEER Y ESCRIBIR?");

        buttonGroupLeerEscribir.add(jRadioButtonLeerEscribirSI);
        jRadioButtonLeerEscribirSI.setText("SI");
        jRadioButtonLeerEscribirSI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonLeerEscribirSIActionPerformed(evt);
            }
        });

        buttonGroupLeerEscribir.add(jRadioButtonLeerEscribirNO);
        jRadioButtonLeerEscribirNO.setText("NO");
        jRadioButtonLeerEscribirNO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonLeerEscribirNOActionPerformed(evt);
            }
        });

        jLabel57.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel57.setText("17.2) NIVEL DE INSTRUCCIÓN");

        jLabel58.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel58.setText("ALCANZADO");

        cmbNivelInstruccion.setEnabled(false);

        javax.swing.GroupLayout JpanelNivelEstudios1Layout = new javax.swing.GroupLayout(JpanelNivelEstudios1);
        JpanelNivelEstudios1.setLayout(JpanelNivelEstudios1Layout);
        JpanelNivelEstudios1Layout.setHorizontalGroup(
            JpanelNivelEstudios1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel57)
            .addComponent(jLabel58)
            .addComponent(cmbNivelInstruccion, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        JpanelNivelEstudios1Layout.setVerticalGroup(
            JpanelNivelEstudios1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JpanelNivelEstudios1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel57)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel58)
                .addGap(26, 26, 26)
                .addComponent(cmbNivelInstruccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jLabel56)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jRadioButtonLeerEscribirSI)
                        .addGap(49, 49, 49)
                        .addComponent(jRadioButtonLeerEscribirNO))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(JpanelNivelEstudios1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel56)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonLeerEscribirSI)
                    .addComponent(jRadioButtonLeerEscribirNO))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JpanelNivelEstudios1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel69.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel69.setText("18) RESIDENCIA HABITUAL DEL");

        jLabel70.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel70.setText("DIVORCIADO");

        jLabel72.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel72.setText("PROVINCIA:");

        jLabel73.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel73.setText("CANTÓN:");

        jLabel74.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel74.setText("PARROQUIA URBANA O RURAL:");

        cmbProvinciaDivorciado.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        cmbCantonDivorciado.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cmbCantonDivorciado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbCantonDivorciadoMouseClicked(evt);
            }
        });

        cmbParroquiaDivorciado.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cmbParroquiaDivorciado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbParroquiaDivorciadoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel69)
                            .addComponent(jLabel70))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel72)
                            .addComponent(jLabel73))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbProvinciaDivorciado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cmbCantonDivorciado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addComponent(jLabel74)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbParroquiaDivorciado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel69)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel70)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel72)
                    .addComponent(cmbProvinciaDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel73)
                    .addComponent(cmbCantonDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel74)
                    .addComponent(cmbParroquiaDivorciado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        jPanel19.setBackground(new java.awt.Color(0, 102, 153));

        txtDPAHom.setBackground(new java.awt.Color(102, 204, 255));
        txtDPAHom.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtDPAHom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDPAHomKeyTyped(evt);
            }
        });

        jLabel71.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel71.setText("USO INEC");

        jLabel75.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel75.setText("DPA");

        txtLocalidadHom.setBackground(new java.awt.Color(102, 204, 255));
        txtLocalidadHom.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtLocalidadHom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLocalidadHomKeyTyped(evt);
            }
        });

        jLabel76.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel76.setText("Localidad");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDPAHom, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel75)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtLocalidadHom, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel76)))
                .addGap(74, 74, 74))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel71)
                .addGap(178, 178, 178))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel71)
                .addGap(18, 18, 18)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDPAHom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLocalidadHom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel75)
                    .addComponent(jLabel76))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panel4Layout = new javax.swing.GroupLayout(panel4);
        panel4.setLayout(panel4Layout);
        panel4Layout.setHorizontalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel4Layout.setVerticalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGroup(panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel4Layout.createSequentialGroup()
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        panel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        panel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel20.setBackground(new java.awt.Color(153, 153, 153));

        jLabel77.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel77.setText("(B) DATOS DE LA DIVORCIADA");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(471, 471, 471)
                .addComponent(jLabel77)
                .addContainerGap(547, Short.MAX_VALUE))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel77)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel21.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel78.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel78.setText("10) NOMBRES Y APELLIDOS");

        txtNombDivorciada.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtNombDivorciada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombDivorciadaKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel78)
                    .addComponent(txtNombDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel78)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtNombDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        jLabel79.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel79.setText("11) NACIONALIDAD");

        buttonGroupNAcionalidadM.add(jRadioButtonEcuatorianoM);
        jRadioButtonEcuatorianoM.setText("Ecuatoriano");
        jRadioButtonEcuatorianoM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonEcuatorianoMActionPerformed(evt);
            }
        });

        buttonGroupNAcionalidadM.add(jRadioButtonExtrangeroM);
        jRadioButtonExtrangeroM.setText("Extrangero");
        jRadioButtonExtrangeroM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonExtrangeroMActionPerformed(evt);
            }
        });

        txtNombrePaisM.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtNombrePaisM.setEnabled(false);
        txtNombrePaisM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombrePaisMKeyReleased(evt);
            }
        });

        jLabel80.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel80.setText("Nombre del pais");

        txtCodPaisM.setBackground(new java.awt.Color(102, 204, 255));
        txtCodPaisM.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtCodPaisM.setEnabled(false);
        txtCodPaisM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodPaisMKeyTyped(evt);
            }
        });

        jLabel81.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel81.setText("USO INEC");

        jLabel82.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel82.setText("Código del pais");

        javax.swing.GroupLayout panel7Layout = new javax.swing.GroupLayout(panel7);
        panel7.setLayout(panel7Layout);
        panel7Layout.setHorizontalGroup(
            panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel7Layout.createSequentialGroup()
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel79)
                    .addGroup(panel7Layout.createSequentialGroup()
                        .addComponent(jRadioButtonEcuatorianoM)
                        .addGap(18, 18, 18)
                        .addComponent(jRadioButtonExtrangeroM)
                        .addGap(32, 32, 32)
                        .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombrePaisM, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel80))
                        .addGap(67, 67, 67)
                        .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel81)
                            .addComponent(jLabel82, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtCodPaisM))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(panel7Layout.createSequentialGroup()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 19, Short.MAX_VALUE))
        );
        panel7Layout.setVerticalGroup(
            panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel7Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(panel7Layout.createSequentialGroup()
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel7Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel79)
                        .addGap(35, 35, 35))
                    .addGroup(panel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel81)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonEcuatorianoM)
                    .addComponent(jRadioButtonExtrangeroM)
                    .addComponent(txtNombrePaisM, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCodPaisM, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel80)
                    .addComponent(jLabel82)))
        );

        panel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel84.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel84.setText("11) No. Cédula De Ciudadania o Pasaporte");

        txtCedulaDivorciada.setBackground(new java.awt.Color(102, 204, 255));
        txtCedulaDivorciada.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtCedulaDivorciada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaDivorciadaKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel84, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtCedulaDivorciada, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel84)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCedulaDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel26.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel85.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel85.setText("12) Fecha de nacimiento");

        jLabel107.setText("Año");

        jLabel108.setText("Mes");

        jLabel109.setText("Día");

        FechaNacimientoDivorciada.setModel(new javax.swing.SpinnerNumberModel(1, 1, 31, 1));

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel85))
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel26Layout.createSequentialGroup()
                                .addComponent(anioNacimientoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(mesNacimientoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel26Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel107)
                                .addGap(64, 64, 64)
                                .addComponent(jLabel108)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel26Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel109))
                            .addComponent(FechaNacimientoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addComponent(jLabel85)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(anioNacimientoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mesNacimientoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FechaNacimientoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel107)
                    .addComponent(jLabel108)
                    .addComponent(jLabel109)))
        );

        jPanel27.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel86.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel86.setText("13) Edad");

        jLabel87.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel87.setText("Años cumplidos a la fecha de inscripción");

        jSpinnerEdadDivorciada.setModel(new javax.swing.SpinnerNumberModel(16, 16, null, 1));

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel86))
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSpinnerEdadDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel87))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addComponent(jLabel86)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel87)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSpinnerEdadDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel28.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel88.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel88.setText("15) Número de hijo a cargo del divorciado");

        jSpinnernumeroHijoDivorciada.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel88))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jSpinnernumeroHijoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addComponent(jLabel88)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSpinnernumeroHijoDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel29.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel89.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel89.setText("16) AUTOIDENTIFICACIÓN");

        jLabel90.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel90.setText("ETNIA DEL DIVORCIADO");

        jLabel91.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel91.setText("Según la cultura y constumbres como");

        jLabel92.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel92.setText("se idetifica el divorciado");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbEtniaM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel92)
                            .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel89, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel90, javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel91, javax.swing.GroupLayout.Alignment.TRAILING)))
                        .addGap(0, 16, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel89)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel90)
                .addGap(1, 1, 1)
                .addComponent(jLabel91)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel92)
                .addGap(33, 33, 33)
                .addComponent(cmbEtniaM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel30.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel102.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel102.setText("17.1) ¿SABE LEER Y ESCRIBIR?");

        buttonGroupLeerEscribirM.add(jRadioButtonLeerEscribirSIM);
        jRadioButtonLeerEscribirSIM.setText("SI");
        jRadioButtonLeerEscribirSIM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonLeerEscribirSIMActionPerformed(evt);
            }
        });

        buttonGroupLeerEscribirM.add(jRadioButton44);
        jRadioButton44.setText("NO");
        jRadioButton44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton44ActionPerformed(evt);
            }
        });

        jLabel103.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel103.setText("17.2) NIVEL DE INSTRUCCIÓN");

        jLabel104.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel104.setText("ALCANZADO");

        cmbNivelInstruccionM.setEnabled(false);

        javax.swing.GroupLayout JpanelNivelEstudios2Layout = new javax.swing.GroupLayout(JpanelNivelEstudios2);
        JpanelNivelEstudios2.setLayout(JpanelNivelEstudios2Layout);
        JpanelNivelEstudios2Layout.setHorizontalGroup(
            JpanelNivelEstudios2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JpanelNivelEstudios2Layout.createSequentialGroup()
                .addGroup(JpanelNivelEstudios2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel103)
                    .addComponent(jLabel104))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(JpanelNivelEstudios2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cmbNivelInstruccionM, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        JpanelNivelEstudios2Layout.setVerticalGroup(
            JpanelNivelEstudios2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JpanelNivelEstudios2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel103)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel104)
                .addGap(18, 18, 18)
                .addComponent(cmbNivelInstruccionM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addComponent(jLabel102)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jRadioButtonLeerEscribirSIM)
                        .addGap(49, 49, 49)
                        .addComponent(jRadioButton44))
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(JpanelNivelEstudios2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel102)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonLeerEscribirSIM)
                    .addComponent(jRadioButton44))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JpanelNivelEstudios2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel31.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel115.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel115.setText("18) RESIDENCIA HABITUAL DEL");

        jLabel116.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel116.setText("DIVORCIADO");

        jLabel117.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel117.setText("PROVINCIA:");

        jLabel118.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel118.setText("CANTÓN:");

        jLabel119.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel119.setText("PARROQUIA URBANA O RURAL:");

        cmbProvinciaDivorciada.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        cmbCantonDivorciada.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cmbCantonDivorciada.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbCantonDivorciadaMouseClicked(evt);
            }
        });

        cmbParroquiaDivorciada.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        cmbParroquiaDivorciada.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbParroquiaDivorciadaMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel117)
                            .addComponent(jLabel118))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbProvinciaDivorciada, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cmbCantonDivorciada, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jLabel119)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbParroquiaDivorciada, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel116)
                            .addComponent(jLabel115))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel115)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel116)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel117)
                    .addComponent(cmbProvinciaDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel118)
                    .addComponent(cmbCantonDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel119)
                    .addComponent(cmbParroquiaDivorciada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel32.setBackground(new java.awt.Color(0, 102, 153));

        txtDPAMujer.setBackground(new java.awt.Color(102, 204, 255));
        txtDPAMujer.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtDPAMujer.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDPAMujerKeyTyped(evt);
            }
        });

        jLabel120.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel120.setText("USO INEC");

        jLabel121.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel121.setText("DPA");

        txtLocalidadMujer.setBackground(new java.awt.Color(102, 204, 255));
        txtLocalidadMujer.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        txtLocalidadMujer.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtLocalidadMujerKeyTyped(evt);
            }
        });

        jLabel122.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel122.setText("Localidad");

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDPAMujer, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel121)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtLocalidadMujer, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel32Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel122)))
                .addGap(74, 74, 74))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel32Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel120)
                .addGap(178, 178, 178))
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel32Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel120)
                .addGap(18, 18, 18)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDPAMujer, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLocalidadMujer, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel121)
                    .addComponent(jLabel122))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panel9Layout = new javax.swing.GroupLayout(panel9);
        panel9.setLayout(panel9Layout);
        panel9Layout.setHorizontalGroup(
            panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel9Layout.createSequentialGroup()
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel9Layout.setVerticalGroup(
            panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panel9Layout.createSequentialGroup()
                .addGroup(panel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panel9Layout.createSequentialGroup()
                        .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout panel5Layout = new javax.swing.GroupLayout(panel5);
        panel5.setLayout(panel5Layout);
        panel5Layout.setHorizontalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panel5Layout.setVerticalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addComponent(panel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel25.setText("USO INEC");

        txtCodCriticoCodifica.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtCodCriticoCodifica.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCodCriticoCodificaKeyTyped(evt);
            }
        });

        jLabel26.setText("Código crítico codificador");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel26)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel25)
                    .addComponent(txtCodCriticoCodifica, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtCodCriticoCodifica, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel26)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(131, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel8.setForeground(new java.awt.Color(51, 255, 51));

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setText("Funcionario del registro civil (nombres y apellidos)");

        TxtNombreFuncionarioRC.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        TxtNombreFuncionarioRC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TxtNombreFuncionarioRCKeyReleased(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel22.setText("Cédula de ciudadanía");

        txtCedulaFuncionarioRC.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtCedulaFuncionarioRC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaFuncionarioRCKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addComponent(jLabel22)
                    .addComponent(TxtNombreFuncionarioRC, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCedulaFuncionarioRC, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TxtNombreFuncionarioRC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtCedulaFuncionarioRC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel22.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel23.setText("Observaciones: Este campo esta destinado para que se pueda anotar cualquier");

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel24.setText("comentario que sirva para clarificar algún dato o cirscuntacion sobre el divorcio.");

        txtObservaciones.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtObservaciones.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtObservacionesKeyReleased(evt);
            }
        });

        btnGuardar.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/guardar.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnAbrirRegistor.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnAbrirRegistor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/buscar.png"))); // NOI18N
        btnAbrirRegistor.setText("VER REGISTROS");
        btnAbrirRegistor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirRegistorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel24)
                            .addComponent(txtObservaciones)))
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(btnGuardar)
                        .addGap(110, 110, 110)
                        .addComponent(btnAbrirRegistor)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtObservaciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnAbrirRegistor))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(panel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(panel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jScrollPane2.setViewportView(jPanel4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1287, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbCantonDivorciadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbCantonDivorciadoMouseClicked
        System.out.println("El item seleccionado es: " + cmbProvinciaDivorciado.getSelectedItem());
        llenarCmbCantonesDivorciado();
    }//GEN-LAST:event_cmbCantonDivorciadoMouseClicked

    private void cmbParroquiaDivorciadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbParroquiaDivorciadoMouseClicked
        System.out.println("El item seleccionado es: " + cmbProvinciaDivorciado.getSelectedItem());
        llenarCmbParroquiasDivorciado();
    }//GEN-LAST:event_cmbParroquiaDivorciadoMouseClicked

    private void cmbCantonDivorciadaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbCantonDivorciadaMouseClicked
        // TODO add your handling code here:
        System.out.println("El item seleccionado es: " + cmbProvinciaDivorciada.getSelectedItem());
        llenarCmbCantonesDivorciada();
    }//GEN-LAST:event_cmbCantonDivorciadaMouseClicked

    private void cmbParroquiaDivorciadaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbParroquiaDivorciadaMouseClicked
        // TODO add your handling code here:
        System.out.println("El item seleccionado es: " + cmbProvinciaDivorciada.getSelectedItem());
        llenarCmbParroquiasDivorciada();
    }//GEN-LAST:event_cmbParroquiaDivorciadaMouseClicked

    private void jPanel2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel2MouseExited
        // TODO add your handling code here:
        int mes = 1 + mesInscripcion.getMonth();
        System.out.println("el año es: " + anioInscricion.getYear());
        System.out.println("El mes es: " + mes);
        System.out.println("La fechas es: " + jSpinnerFechaInscripcion.getValue());
    }//GEN-LAST:event_jPanel2MouseExited

    private void cmbParroquiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbParroquiaMouseClicked
        // TODO add your handling code here:
        System.out.println("El item seleccionado es: " + CmbProvincias.getSelectedItem());
        llenarCmbParroquias();
    }//GEN-LAST:event_cmbParroquiaMouseClicked

    private void CmbCantonesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CmbCantonesMouseClicked
        // TODO add your handling code here:
        System.out.println("El item seleccionado es: " + CmbProvincias.getSelectedItem());
        llenarCmbCantones();
    }//GEN-LAST:event_CmbCantonesMouseClicked

    private void CmbProvinciasItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_CmbProvinciasItemStateChanged
        // TODO add your handling code here:
        CmbCantones.removeAllItems();
        cmbParroquia.removeAllItems();
    }//GEN-LAST:event_CmbProvinciasItemStateChanged

    private void panel6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel6MouseExited
        // TODO add your handling code here:

//        try {
//            
//            ProcedimientosAlamacenados.insertarDatosDivorcio1(fecha, "SI", "4", "Mutuo Acuerdo");
//            
////        }
//        } catch (SQLException ex) {
//            Logger.getLogger(JF_FormularioDivorcio.class.getName()).log(Level.SEVERE, null, ex);
//            System.out.println("no se pudo guardar en la base de datos");
//        }
//        try{
//            s =connection.createStatement();
//            rs = s.executeQuery("select idmatrimonio from datos_divorcio");
//            System.out.println("llenando causas divorcio");
//        }catch (Exception e){
//            System.out.println("Revise la sentecia no se puede conectar a la base de datos: "
//                    + " tipo de error: "+e);
//        }
//        String cusas = "";
//        try{
//            while (rs.next()){
//                cusas = rs.getString(1);
//                System.out.println("Los id de causas son: "+cusas);
//            }
//            System.out.println("La causa final fue: "+cusas);
//            int id = Integer.parseInt(cusas)+1;
//            String conversion= String.valueOf(id);
//            ProcedimientosAlamacenados.insertarDatosDivorcio1(conversion,fecha, "SI", "4", "Mutuo Acuerdo");
//        }catch (Exception e){
//            int id = Integer.parseInt(cusas)+1;
//            System.out.println("No se puede llenar el combo provincias: "+e);
//            System.out.println("eL ID A ALMACENARCE: "+id);
//        }

    }//GEN-LAST:event_panel6MouseExited

    private void panel3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel3MouseExited

    }//GEN-LAST:event_panel3MouseExited

    private void panel4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panel4MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_panel4MouseExited

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:

//        boolean accionesCompletas = false;
//1 TABLA USUARIOS
        int mesmatrimonio = 1 + mesMatrimonio.getMonth();
        String fecha = anioMatrimonio.getYear() + "" + mesmatrimonio + "" + FechaMatrimonio.getValue().toString();
//        int fechaCover = Integer.parseInt(fecha);
        int diaMat = Integer.parseInt(FechaMatrimonio.getValue().toString());
        String mesMatri = mesmatrimonio + "";
        String diaMAtrimonio = diaMat + "";
        if (mesmatrimonio < 10) {
            mesMatri = "0" + mesmatrimonio;
        }
        if (diaMat < 10) {
            diaMAtrimonio = "0" + diaMat;
        }
        String afirmacion = "";
        String fechaCompleta = anioMatrimonio.getYear() + mesMatri + diaMAtrimonio;
        String causa = cmbCausa.getSelectedItem().toString();
        if (cmbCausa.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una causa de divorcio");
            return;
        } else {
            if (jRadioButtonSiBienes.isSelected()) {
                afirmacion = "SI";
                System.out.println("Fue con capitulacion de bienes: " + afirmacion);
            } else if (jRadioButtonNoBienes.isSelected()) {
                afirmacion = "NO";
                System.out.println("Fue con capitulacion de bienes: " + afirmacion);
            } else {
                JOptionPane.showMessageDialog(this, "Escoja si el matrimonio fue con capitulacion de bienes");
                return;
            }
            String aniosMatrimonio = jSpinnerAniosMatrimonio.getValue().toString();
            if (jSpinnerAniosMatrimonio.getValue().equals("0")) {
                JOptionPane.showMessageDialog(this, "Escoja almenos un año de matrimonio");
                return;
            } else {
                System.out.println(" los aÑos de matrimonio son: " + aniosMatrimonio);
                GuardarUsuario(fechaCompleta, afirmacion, aniosMatrimonio, causa);
                System.out.println("Se registro con exito");

                //2     TABLA NACIONALIDAD HOMBRE
                String nacionalidad;
                String paisNacimiento;
                String codigo;

                if (jRadioButtonEcuatorianoH.isSelected()) {
                    txtNombrePaisH.setText("");
                    txtCodPaisH.setText("");
                    txtNombrePaisH.setEnabled(false);
                    txtCodPaisH.setEnabled(false);
                    nacionalidad = "ECUATORIANA";
                    paisNacimiento = "ECUADOR";
                    codigo = 593 + "";
                    GuardarNAcionalidad(nacionalidad, paisNacimiento, codigo);
                    llenarTablasUbicacionDatosPerson();
                    return;
                } else if (jRadioButtonExtranjeroH.isSelected()) {
                    txtCodPaisH.setEnabled(true);
                    txtNombrePaisH.setEnabled(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Escoja una nacionalidad");
                    return;
                }
                if (txtNombrePaisH.equals("") || txtCodPaisH.equals("")) {
                    JOptionPane.showMessageDialog(this, "Llene los campos nacionalidad y codigo de pais");
                } else {
                    nacionalidad = "EXTRANJERO";
                    paisNacimiento = txtNombrePaisH.getText();
                    codigo = (txtCodPaisH.getText());
                    GuardarNAcionalidad(nacionalidad, paisNacimiento, codigo);
                }

                //2     TABLA NACIONALIDAD MUJER
                String nacionalidadM;
                String paisNacimientM;
                String codigoM;

                if (jRadioButtonEcuatorianoM.isSelected()) {
                    txtNombrePaisM.setText("");
                    txtCodPaisM.setText("");
                    txtNombrePaisM.setEnabled(false);
                    txtCodPaisM.setEnabled(false);
                    nacionalidadM = "ECUATORIANA";
                    paisNacimientM = "ECUADOR";
                    codigoM = 593 + "";
                    GuardarNAcionalidad(nacionalidadM, paisNacimientM, codigoM);
                    llenarTablasUbicacionDatosPerson();
                    return;
                } else if (jRadioButtonExtrangeroM.isSelected()) {
                    txtCodPaisM.setEnabled(true);
                    txtNombrePaisM.setEnabled(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Escoja una nacionalidad");
                    return;
                }
                if (txtNombrePaisM.equals("") || txtCodPaisM.equals("")) {
                    JOptionPane.showMessageDialog(this, "Llene los campos nacionalidad y codigo de pais");
                } else {
                    nacionalidadM = "EXTRANJERO";
                    paisNacimientM = txtNombrePaisM.getText();
                    codigoM = (txtCodPaisM.getText());
                    GuardarNAcionalidad(nacionalidadM, paisNacimientM, codigoM);
                }

            }

        }
        llenarTablasUbicacionDatosPerson();
        //        
    }//GEN-LAST:event_btnGuardarActionPerformed

    public void llenarTablasUbicacionDatosPerson() {
        //3      TABLA UBICACION
        System.out.println("La provincia obtenida es: " + cmbParroquiaDivorciado.getSelectedItem());
        System.out.println("Lo obtenido en canton es: " + cmbCantonDivorciado.getSelectedItem());
        System.out.println("La parroquia es: " + cmbParroquiaDivorciado.getSelectedItem());

        String provincia = (String) cmbProvinciaDivorciado.getSelectedItem();
        String canton = (String) cmbCantonDivorciado.getSelectedItem();
        String localidad = (String) cmbParroquiaDivorciado.getSelectedItem();

        try {
            if (canton.equals("") || localidad.equals("")) {
                System.out.println("Escoja un lugar de residencia del Divorciado");
            } else {

                GuardarUbicacion(provincia, canton, localidad);
                System.out.println("Ubicacion guardada");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "No ha escogido un lugar de residencia"
                    + "del divorciado");
        }

// 4     TABLA DATOS PERSONALES ----En curso
        System.out.println("****************TRATANDO DE REGISTRAR DATOS PERSONLES");
        String nombDivorciado = txtNombDivorciado.getText();
        String cedula = txtCedulaDivorciado.getText();
        String idInstruccion = "";
        String autoidentificacion = "";
        String nacionalidadH = "";
        String edadH = "";
        String hijosCargoH = "";
        String idUbicacion = "";
        if (nombDivorciado.equals("") || cedula.equals("")) {
            JOptionPane.showMessageDialog(this, "Llene los campos de nombre y"
                    + "cédula del divorciado");
        } else if (validaCedula(cedula) == false) {
            JOptionPane.showMessageDialog(null, "Número de cédula no válido!!", "Error", JOptionPane.WARNING_MESSAGE);
        } else {
            System.out.println("++++++++++ NUMERO DE CEDULA VALIDO");
            if (jRadioButtonLeerEscribirSI.isSelected()) {
                if (cmbNivelInstruccion.getSelectedIndex() == 0) {
                    JOptionPane.showMessageDialog(this, "Seleccione un nivel de instrccion");
                    return;
                }
                idInstruccion = (cmbNivelInstruccion.getSelectedIndex() + 1) + "";
            } else {
                idInstruccion = 0 + "";
            }

            if (cmbEtnia.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "seleccione una etnia");
                return;
            } else {
                autoidentificacion = String.valueOf(cmbEtnia.getSelectedIndex());
//--------------------- obteniendo la nacionlalidad hombre
                Conexion();
                System.out.println("**************** TRATANDO DE OBTENER LA NACIONALIDAD DEL HOMBRE");
                try {
                    s = connection.createStatement();
                    rs = s.executeQuery("SELECT MAX(idnacionalidad) FROM nacionalidad;");
                    System.out.println("---------------Obteniendo la nacionlaidad");
                } catch (Exception e) {
                    System.out.println("Revise la sentecia no se puede conectar a la base de datos para la nacionalidad: "
                            + " tipo de error: " + e);
                }
                try {
                    while (rs.next()) {
                        nacionalidadH = rs.getString(1);
                        System.out.println("*************** LA NACIONALIDAD FUE eNCONTRADA y es :" + nacionalidadH);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Error al tratar de cargar la nacionalidad en datos personales");
                }

//---------------------- fin obteniendo la nacionalidad hombre
//----------------------inicio fecha nacimiento hombre
                int mesNaciH = 1 + mesNacimientoDivorciado.getMonth();
                String fechaNaciH = anioNacimientoDivorciado.getYear() + "" + mesNaciH + "" + FechaNacimientoDivorciado.getValue().toString();
//        int fechaCover = Integer.parseInt(fecha);
                int diaNAciH = Integer.parseInt(FechaNacimientoDivorciado.getValue().toString());
                String mesStringNaciH = mesNaciH + "";
                String diaStringNaciH = diaNAciH + "";
                if (mesNaciH < 10) {
                    mesStringNaciH = "0" + mesNaciH;
                }
                if (diaNAciH < 10) {
                    diaStringNaciH = "0" + diaNAciH;
                }
//                String afirmacion = "";
                String fechaCompletaNaciH = anioNacimientoDivorciado.getYear() + mesStringNaciH + diaStringNaciH;
//----------------------fin fecha nacimiento hombre

//----------------------inicio edad hombre e hijos a cargo
                edadH = String.valueOf(jSpinnerEdadDivorciado.getValue());
                hijosCargoH = String.valueOf(jSpinnernumeroHijoDivorciado.getValue());

                String DpaH = txtDPAHom.getText();
                String localidadH = txtLocalidadHom.getText();
                if (DpaH.equals("") || localidadH.equals("")) {
                    JOptionPane.showMessageDialog(this, "Llene los campos DPA y localida de divociado");
                    return;
                } else {
//----------------------- TRATANDO DE OBTENER ID DE LA UBICACION y FECHA DE NACIMIENTO DEL DIVORCIADO
                    Conexion();
                    System.out.println("**************** TRATANDO DE OBTENER LA NACIONALIDAD DEL HOMBRE");
                    try {
                        s = connection.createStatement();
                        rs = s.executeQuery("SELECT MAX(idubicacion) FROM ubicacion;");
                        System.out.println("---------------Obteniendo la UBICACION");
                    } catch (Exception e) {
                        System.out.println("Revise la sentecia no se puede conectar a la base de datos para la UBICACION: "
                                + " tipo de error: " + e);
                    }
                    try {
                        while (rs.next()) {
                            idUbicacion = rs.getString(1);
                            System.out.println("*************** LA NACIONALIDAD FUE ENCONTRADA y es :" + idUbicacion);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(this, "Error al tratar de cargar la nacionalidad en datos personales");
                    }

//------------------------ FIN DE OBTENER LA UBICACION
                    String idCausa = String.valueOf(cmbCausa.getSelectedIndex());
                    System.out.println("La fecha que se quiere ingresar es: " + fechaCompletaNaciH);
//
                    guardarDatosPersonales(idInstruccion, nacionalidadH, autoidentificacion, idUbicacion, cedula, fechaCompletaNaciH, edadH, hijosCargoH, "MASCULINO", DpaH, localidadH, nombDivorciado);

                }
//
            }
        }

//--------------------Inicio Ubicacion Mujer   
//3      TABLA UBICACION
        System.out.println("La provincia obtenida es: " + cmbParroquiaDivorciada.getSelectedItem());
        System.out.println("Lo obtenido en canton es: " + cmbCantonDivorciada.getSelectedItem());
        System.out.println("La parroquia es: " + cmbParroquiaDivorciada.getSelectedItem());

        String provinciaM = (String) cmbProvinciaDivorciada.getSelectedItem();
        String cantonM = (String) cmbCantonDivorciada.getSelectedItem();
        String localidadM = (String) cmbParroquiaDivorciada.getSelectedItem();

        try {
            if (cantonM.equals("") || localidadM.equals("")) {
                System.out.println("Escoja un lugar de residencia dela Divorciada");
            } else {

                GuardarUbicacion(provinciaM, cantonM, localidadM);
                System.out.println("Ubicacion guardada");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "No ha escogido un lugar de residencia"
                    + "del divorciado");
        }

// 4     TABLA DATOS PERSONALES ----En curso
        System.out.println("****************TRATANDO DE REGISTRAR DATOS PERSONLES DIVORCIADA");
        String nombDivorciada = txtNombDivorciada.getText();
        String cedulaM = txtCedulaDivorciada.getText();
        String idInstruccionM = "";
        String autoidentificacionM = "";
        String nacionalidadM = "";
        String edadM = "";
        String hijosCargoM = "";
        String idUbicacionM = "";
        if (nombDivorciada.equals("") || cedulaM.equals("")) {
            JOptionPane.showMessageDialog(this, "Llene los campos de nombre y"
                    + "cédula del divorciado");
        } else if (validaCedula(cedulaM) == false) {
            JOptionPane.showMessageDialog(null, "Número de cédula no válido!!", "Error", JOptionPane.WARNING_MESSAGE);
        } else {
            System.out.println("++++++++++ NUMERO DE CEDULA VALIDO");
            if (jRadioButtonLeerEscribirSIM.isSelected()) {
                if (cmbNivelInstruccionM.getSelectedIndex() == 0) {
                    JOptionPane.showMessageDialog(this, "Seleccione un nivel de instrccion");
                    return;
                }
                idInstruccionM = (cmbNivelInstruccionM.getSelectedIndex() + 1) + "";
            } else {
                idInstruccionM = 0 + "";
            }

            if (cmbEtniaM.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(this, "seleccione una etnia");
                return;
            } else {
                autoidentificacionM = String.valueOf(cmbEtniaM.getSelectedIndex());
//--------------------- obteniendo la nacionlalidad hombre
                Conexion();
                System.out.println("**************** TRATANDO DE OBTENER LA NACIONALIDAD DE LA MUJER");
                try {
                    s = connection.createStatement();
                    rs = s.executeQuery("SELECT MAX(idnacionalidad) FROM nacionalidad;");
                    System.out.println("---------------Obteniendo la nacionlaidad");
                } catch (Exception e) {
                    System.out.println("Revise la sentecia no se puede conectar a la base de datos para la nacionalidad: "
                            + " tipo de error: " + e);
                }
                try {
                    while (rs.next()) {
                        nacionalidadM = rs.getString(1);
                        System.out.println("*************** LA NACIONALIDAD FUE eNCONTRADA y es :" + nacionalidadM);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Error al tratar de cargar la nacionalidad en datos personales");
                }

//---------------------- fin obteniendo la nacionalidad hombre
//----------------------inicio fecha nacimiento hombre
                int mesNaciH = 1 + mesNacimientoDivorciada.getMonth();
                String fechaNaciH = anioNacimientoDivorciada.getYear() + "" + mesNaciH + "" + FechaNacimientoDivorciada.getValue().toString();
//        int fechaCover = Integer.parseInt(fecha);
                int diaNAciH = Integer.parseInt(FechaNacimientoDivorciada.getValue().toString());
                String mesStringNaciH = mesNaciH + "";
                String diaStringNaciH = diaNAciH + "";
                if (mesNaciH < 10) {
                    mesStringNaciH = "0" + mesNaciH;
                }
                if (diaNAciH < 10) {
                    diaStringNaciH = "0" + diaNAciH;
                }
//                String afirmacion = "";
                String fechaCompletaNaciM = anioNacimientoDivorciada.getYear() + mesStringNaciH + diaStringNaciH;
//----------------------fin fecha nacimiento hombre

//----------------------inicio edad hombre e hijos a cargo
                edadM = String.valueOf(jSpinnerEdadDivorciada.getValue());
                hijosCargoM = String.valueOf(jSpinnernumeroHijoDivorciada.getValue());

                String DpaM = txtDPAMujer.getText();
                String localidadMujer = txtLocalidadMujer.getText();
                if (DpaM.equals("") || localidadMujer.equals("")) {
                    JOptionPane.showMessageDialog(this, "Llene los campos DPA y localida de divociada");
                    return;
                } else {
//----------------------- TRATANDO DE OBTENER ID DE LA UBICACION y FECHA DE NACIMIENTO DEL DIVORCIADA
                    Conexion();
                    System.out.println("**************** TRATANDO DE OBTENER LA NACIONALIDAD DE LA MUJER");
                    try {
                        s = connection.createStatement();
                        rs = s.executeQuery("SELECT MAX(idubicacion) FROM ubicacion;");
                        System.out.println("---------------Obteniendo la UBICACION");
                    } catch (Exception e) {
                        System.out.println("Revise la sentecia no se puede conectar a la base de datos para la UBICACION: "
                                + " tipo de error: " + e);
                    }
                    try {
                        while (rs.next()) {
                            idUbicacionM = rs.getString(1);
                            System.out.println("*************** LA NACIONALIDAD FUE ENCONTRADA y es :" + idUbicacionM);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(this, "Error al tratar de cargar la nacionalidad en datos personales");
                    }

//------------------------ FIN DE OBTENER LA UBICACION
                    String idCausa = String.valueOf(cmbCausa.getSelectedIndex());
                    System.out.println("La fecha que se quiere ingresar es: " + fechaCompletaNaciM);
//
                    guardarDatosPersonales(idInstruccionM, nacionalidadM, autoidentificacionM, idUbicacionM, cedulaM, fechaCompletaNaciM, edadM, hijosCargoM, "FEMENINO", DpaM, localidadMujer, nombDivorciada);

                            System.out.println("Comienza a llenar formulario completo");

        //     LLENAR LA TABLA DEL FORMULARIO  
        String idUbicacionFormulario = "";      //tabla ubicacion
        String idMatrimonio = "";               //tabla datos personales
        String idPersona = "";                  //tabla datos divorcio
        String nombOficina = txtnombOfiRC.getText();
        String fechaInscripcionFor = "";
        String necForm = txtInecForm.getText();
        String numeroOfi = txtNunOficina.getText();
        String actaInscripcion = txtActaInscripcion.getText();
        String fechaSentenciaForm = "";
        String nombFuncionario = TxtNombreFuncionarioRC.getText();
        String cedulaFuncionario = txtCedulaFuncionarioRC.getText();
        String observaciones = txtObservaciones.getText();
        String codigoCritico = txtCodCriticoCodifica.getText();

        if (nombOficina.equals("") || actaInscripcion.equals("") || nombFuncionario.equals("")
                || cedulaFuncionario.equals("") || observaciones.equals("") || codigoCritico.equals("") || numeroOfi.equals("")) {
            JOptionPane.showMessageDialog(this, "Asegurese de haber llenado todos los campos\n"
                    + "Puede revizar: Numero de oficina,Acta de inscripción, nombre del Funcionario,\n"
                    + "Número de oficina , Cédula del funcionario, Observacoines o código crítico");
            return;
        } else {
            System.out.println("Vefifico que los campos esten llenos por lo que continual");
//     ------------ llenado ubicacion de DEL REGISTRO CIVIL
            System.out.println("La provincia obtenida de ubicacion del formulario es: " + CmbProvincias.getSelectedItem());
            System.out.println("Lo obtenido en canton del formulario es: " + CmbCantones.getSelectedItem());
            System.out.println("La parroquia del formulario es: " + cmbParroquia.getSelectedItem());

            String provinciaRC = (String) CmbProvincias.getSelectedItem();
            String cantonRC = (String) CmbCantones.getSelectedItem();
            String localidadRC = (String) cmbParroquia.getSelectedItem();

            try {
                if (cantonRC.equals("") || localidadRC.equals("")) {
                    JOptionPane.showMessageDialog(this, "Escoja el lugar de en donde se esta llevando a cabo el tramite");
                    return;
                } else {

                    GuardarUbicacion(provinciaRC, cantonRC, localidadRC);
                    System.out.println("Ubicacion del formulario guardada");

//                    OBteniendo ubicacio del formulario
                    try {
                        s = connection.createStatement();
                        rs = s.executeQuery("SELECT MAX(idubicacion) FROM ubicacion;");
                        System.out.println("---------------Obteniendo la UBICACION");
                    } catch (Exception e) {
                        System.out.println("Revise la sentecia no se puede conectar a la base de datos para la UBICACION: "
                                + " tipo de error: " + e);
                    }
                    try {
                        while (rs.next()) {
                            idUbicacionFormulario = rs.getString(1);
                            System.out.println("*************** LA UBICACION DEL FORMULARIO y es :" + idUbicacionFormulario);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(this, "Error al tratar de cargar la nacionalidad en datos personales");
                    }
//                    fin de obtener la ubicaion del formulario

//  --------------------  obteniedo id de matrimonio
                    try {
                        s = connection.createStatement();
                        rs = s.executeQuery("select max(idmatrimonio) from datos_divorcio;");
                        System.out.println("---------------Obteniendo el id de matrimonio");
                    } catch (Exception e) {
                        System.out.println("Revise la sentecia no se puede conectar a la base de datos para la UBICACION: "
                                + " tipo de error: " + e);
                    }
                    try {
                        while (rs.next()) {
                            idMatrimonio = rs.getString(1);
                            System.out.println("*************** EL ID DE MATRIMONIO y es :" + idMatrimonio);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(this, "Error al tratar de cargar el id de matrimonio");
                    }
//---------------------   Fin de obteniedo id de matrimonio

                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "No ha escogido el lugar en donde se esta llevando a cabo el formulario");
            }

            int mesFormulario = 1 + mesInscripcion.getMonth();
            String fechaIns = anioInscricion.getYear() + "" + mesFormulario + "" + jSpinnerFechaInscripcion.getValue().toString();
//        int fechaCover = Integer.parseInt(fecha);
            int diaInscri = Integer.parseInt(jSpinnerFechaInscripcion.getValue().toString());
            String mesInscri = mesFormulario + "";
            String diaInscripcion = diaInscri + "";
            if (mesFormulario < 10) {
                mesInscri = "0" + mesFormulario;
            }
            if (diaInscri < 10) {
                diaInscripcion = "0" + diaInscri;
            }

//            Fechas de sentencias 
            int mesSentencia = 1 + mesInscripcion.getMonth();
//            String fechaIns = anioInscricion.getYear() + "" + mesSentencia + "" + jSpinnerFechaInscripcion.getValue().toString();
            int diaSentencia = Integer.parseInt(jSpinnerFechaInscripcion.getValue().toString());
            String mesSente = mesSentencia + "";
            String diaSenten = diaSentencia + "";
            if (mesSentencia < 10) {
                mesSente = "0" + mesSentencia;
            }
            if (diaSentencia < 10) {
                diaSenten = "0" + diaSentencia;
            }

            fechaSentenciaForm = anioSentencia.getYear() + mesSente + diaSenten;
            fechaInscripcionFor = anioInscricion.getYear() + mesInscri + diaInscripcion;

            if (validaCedula(txtCedulaDivorciado.getText()) == false) {
                JOptionPane.showMessageDialog(this, "El número de cedula del funcionario no es válido");
            } else {

                try {
                    s = connection.createStatement();
                    rs = s.executeQuery("select max(iddatoperso) from datos_personales;");
                    System.out.println("---------------Obteniendo el id de matrimonio");
                } catch (Exception e) {
                    System.out.println("Revise la sentecia no se puede conectar a la base de datos para ID DE DATOS PERSONALES: "
                            + " tipo de error: " + e);
                }
                try {
                    while (rs.next()) {
                        idPersona = rs.getString(1);
                        System.out.println("*************** EL ID DE DTOS PERSONALES  y es :" + idPersona);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Error al tratar de cargar el id de DATOS PERSONALES");
                }
                llenarFormulario(idUbicacionFormulario, idMatrimonio, idPersona, nombOficina, fechaInscripcionFor, necForm, numeroOfi, actaInscripcion,
                        fechaSentenciaForm, nombFuncionario, cedulaFuncionario, observaciones, codigoCritico);
            }

//-------------    FIN DE ------------ llenado ubicacion de DEL REGISTRO CIVIL        
        }

                    
                }
//
            }
        }

//--------------------Fin de la ubicacion Mujer
    }

    public static boolean validaCedula(String x) {
        int suma = 0;
        if (x.length() == 9) {
            System.out.println("Ingrese su cedula de 10 digitos");
            return false;
        } else {
            int a[] = new int[x.length() / 2];
            int b[] = new int[(x.length() / 2)];
            int c = 0;
            int d = 1;
            for (int i = 0; i < x.length() / 2; i++) {
                a[i] = Integer.parseInt(String.valueOf(x.charAt(c)));
                c = c + 2;
                if (i < (x.length() / 2) - 1) {
                    b[i] = Integer.parseInt(String.valueOf(x.charAt(d)));
                    d = d + 2;
                }
            }

            for (int i = 0; i < a.length; i++) {
                a[i] = a[i] * 2;
                if (a[i] > 9) {
                    a[i] = a[i] - 9;
                }
                suma = suma + a[i] + b[i];
            }
            int aux = suma / 10;
            int dec = (aux + 1) * 10;
            if ((dec - suma) == Integer.parseInt(String.valueOf(x.charAt(x.length() - 1)))) {
                System.out.println("Valida");
                return true;
            } else if (suma % 10 == 0 && x.charAt(x.length() - 1) == '0') {
                System.out.println("Valida");
                return true;
            } else {
                System.out.println("No Valida");
                return false;
            }

        }
    }

    private void jRadioButtonLeerEscribirSIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonLeerEscribirSIActionPerformed
        // TODO add your handling code here:
        cmbNivelInstruccion.setEnabled(true);
        cmbNivelInstruccion.removeAllItems();
//        cmbNivelInstruccionM.removeAllItems();
        llenarCmbNivelInstruccion();
    }//GEN-LAST:event_jRadioButtonLeerEscribirSIActionPerformed

    private void jRadioButtonLeerEscribirNOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonLeerEscribirNOActionPerformed
        // TODO add your handling code here:
        cmbNivelInstruccion.setEnabled(false);
        cmbNivelInstruccion.removeAllItems();
    }//GEN-LAST:event_jRadioButtonLeerEscribirNOActionPerformed

    private void jRadioButtonExtranjeroHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonExtranjeroHActionPerformed
        // TODO add your handling code here:
        txtCodPaisH.setEnabled(true);
        txtNombrePaisH.setEnabled(true);
    }//GEN-LAST:event_jRadioButtonExtranjeroHActionPerformed

    private void jRadioButtonEcuatorianoHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonEcuatorianoHActionPerformed
        // TODO add your handling code here:
        txtCodPaisH.setEnabled(false);
        txtNombrePaisH.setEnabled(false);
    }//GEN-LAST:event_jRadioButtonEcuatorianoHActionPerformed

    private void jRadioButtonLeerEscribirSIMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonLeerEscribirSIMActionPerformed
        // TODO add your handling code here:
        cmbNivelInstruccionM.setEnabled(true);
        cmbNivelInstruccionM.removeAllItems();
//        cmbNivelInstruccionM.removeAllItems();
        llenarCmbNivelInstruccion();
    }//GEN-LAST:event_jRadioButtonLeerEscribirSIMActionPerformed

    private void jRadioButton44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton44ActionPerformed
        // TODO add your handling code here:
        cmbNivelInstruccionM.setEnabled(false);
        cmbNivelInstruccionM.removeAllItems();
    }//GEN-LAST:event_jRadioButton44ActionPerformed

    private void jRadioButtonEcuatorianoMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonEcuatorianoMActionPerformed
        // TODO add your handling code here:
        txtCodPaisM.setEnabled(false);
        txtNombrePaisM.setEnabled(false);
    }//GEN-LAST:event_jRadioButtonEcuatorianoMActionPerformed

    private void jRadioButtonExtrangeroMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonExtrangeroMActionPerformed
        // TODO add your handling code here:
        txtCodPaisM.setEnabled(true);
        txtNombrePaisM.setEnabled(true);
    }//GEN-LAST:event_jRadioButtonExtrangeroMActionPerformed

    private void btnAbrirRegistorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirRegistorActionPerformed
        // TODO add your handling code here:
        FormulariosRegistrados abrir = new FormulariosRegistrados();
        abrir.setVisible(true);
        super.dispose();
    }//GEN-LAST:event_btnAbrirRegistorActionPerformed

    private void txtCedulaDivorciadoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaDivorciadoKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la cédula!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la cédula!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtCedulaDivorciado.transferFocus();
        }
    }//GEN-LAST:event_txtCedulaDivorciadoKeyTyped

    private void txtCedulaDivorciadaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaDivorciadaKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la cédula!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la cédula!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtCedulaDivorciada.transferFocus();
        }
    }//GEN-LAST:event_txtCedulaDivorciadaKeyTyped

    private void txtDPAHomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDPAHomKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en DAP!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en DAP!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtDPAHom.transferFocus();
        }
    }//GEN-LAST:event_txtDPAHomKeyTyped

    private void txtLocalidadHomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtLocalidadHomKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la localidad!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la localidad!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtLocalidadHom.transferFocus();
        }
    }//GEN-LAST:event_txtLocalidadHomKeyTyped

    private void txtCodPaisHKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodPaisHKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en Codigo del Pais!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en Codigo del pais!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtCodPaisH.transferFocus();
        }
    }//GEN-LAST:event_txtCodPaisHKeyTyped

    private void txtCodPaisMKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodPaisMKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en codigo del pais!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en codigo del pais!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtCodPaisM.transferFocus();
        }
    }//GEN-LAST:event_txtCodPaisMKeyTyped

    private void txtCedulaFuncionarioRCKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaFuncionarioRCKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la cédula!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la cédula!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtCedulaFuncionarioRC.transferFocus();
        }
    }//GEN-LAST:event_txtCedulaFuncionarioRCKeyTyped

    private void txtCodCriticoCodificaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCodCriticoCodificaKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en código critico!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en código critico!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtCodCriticoCodifica.transferFocus();
        }
    }//GEN-LAST:event_txtCodCriticoCodificaKeyTyped

    private void txtDPAMujerKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDPAMujerKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en DPA!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en DPA!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtDPAMujer.transferFocus();
        }
    }//GEN-LAST:event_txtDPAMujerKeyTyped

    private void txtLocalidadMujerKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtLocalidadMujerKeyTyped
        // TODO add your handling code here:
        int k = (int) evt.getKeyChar();
        if (k >= 97 && k <= 122 || k >= 65 && k <= 90) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la localidad!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 241 || k == 209) {
            evt.setKeyChar((char) KeyEvent.VK_CLEAR);
            JOptionPane.showMessageDialog(null, "No puede ingresar letras en la localidad!!!", "Error de letras", JOptionPane.ERROR_MESSAGE);
        }
        if (k == 10) {
            txtLocalidadMujer.transferFocus();
        }
    }//GEN-LAST:event_txtLocalidadMujerKeyTyped

    private void txtnombOfiRCKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnombOfiRCKeyReleased
        // TODO add your handling code here:
        String cadena = (txtnombOfiRC.getText()).toUpperCase();
        txtnombOfiRC.setText(cadena);
    }//GEN-LAST:event_txtnombOfiRCKeyReleased

    private void TxtNombreFuncionarioRCKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TxtNombreFuncionarioRCKeyReleased
        // TODO add your handling code here:
        String cadena = (TxtNombreFuncionarioRC.getText()).toUpperCase();
        TxtNombreFuncionarioRC.setText(cadena);
    }//GEN-LAST:event_TxtNombreFuncionarioRCKeyReleased

    private void txtObservacionesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtObservacionesKeyReleased
        // TODO add your handling code here:
        String cadena = (txtObservaciones.getText()).toUpperCase();
        txtObservaciones.setText(cadena);
    }//GEN-LAST:event_txtObservacionesKeyReleased

    private void txtNombDivorciadoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombDivorciadoKeyReleased
        // TODO add your handling code here:
        String cadena = (txtNombDivorciado.getText()).toUpperCase();
        txtNombDivorciado.setText(cadena);
    }//GEN-LAST:event_txtNombDivorciadoKeyReleased

    private void txtNombDivorciadaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombDivorciadaKeyReleased
        // TODO add your handling code here:
        String cadena = (txtNombDivorciada.getText()).toUpperCase();
        txtNombDivorciada.setText(cadena);
    }//GEN-LAST:event_txtNombDivorciadaKeyReleased

    private void txtNombrePaisMKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombrePaisMKeyReleased
        // TODO add your handling code here:
        String cadena = (txtNombrePaisM.getText()).toUpperCase();
        txtNombrePaisM.setText(cadena);
    }//GEN-LAST:event_txtNombrePaisMKeyReleased

    private void txtNombrePaisHKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombrePaisHKeyReleased
        // TODO add your handling code here:
        String cadena = (txtNombrePaisH.getText()).toUpperCase();
        txtNombrePaisH.setText(cadena);
    }//GEN-LAST:event_txtNombrePaisHKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JF_FormularioDivorcio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JF_FormularioDivorcio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JF_FormularioDivorcio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JF_FormularioDivorcio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JF_FormularioDivorcio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CmbCantones;
    private javax.swing.JComboBox<String> CmbProvincias;
    private javax.swing.JSpinner FechaMatrimonio;
    private javax.swing.JSpinner FechaNacimientoDivorciada;
    private javax.swing.JSpinner FechaNacimientoDivorciado;
    private javax.swing.JSpinner FechaSentencia;
    private javax.swing.JPanel JpanelNivelEstudios1;
    private javax.swing.JPanel JpanelNivelEstudios2;
    private com.toedter.calendar.JMonthChooser MesSentencia;
    private javax.swing.JTextField TxtNombreFuncionarioRC;
    private com.toedter.calendar.JYearChooser anioInscricion;
    private com.toedter.calendar.JYearChooser anioMatrimonio;
    private com.toedter.calendar.JYearChooser anioNacimientoDivorciada;
    private com.toedter.calendar.JYearChooser anioNacimientoDivorciado;
    private com.toedter.calendar.JYearChooser anioSentencia;
    private javax.swing.JButton btnAbrirRegistor;
    private javax.swing.JButton btnGuardar;
    private javax.swing.ButtonGroup buttonGroupBienes;
    private javax.swing.ButtonGroup buttonGroupLeerEscribir;
    private javax.swing.ButtonGroup buttonGroupLeerEscribirM;
    private javax.swing.ButtonGroup buttonGroupNAcionalidadM;
    private javax.swing.ButtonGroup buttonGroupNacionalidad;
    private javax.swing.JComboBox<String> cmbCantonDivorciada;
    private javax.swing.JComboBox<String> cmbCantonDivorciado;
    private javax.swing.JComboBox<String> cmbCausa;
    private javax.swing.JComboBox<String> cmbEtnia;
    private javax.swing.JComboBox<String> cmbEtniaM;
    private javax.swing.JComboBox<String> cmbNivelInstruccion;
    private javax.swing.JComboBox<String> cmbNivelInstruccionM;
    private javax.swing.JComboBox<String> cmbParroquia;
    private javax.swing.JComboBox<String> cmbParroquiaDivorciada;
    private javax.swing.JComboBox<String> cmbParroquiaDivorciado;
    private javax.swing.JComboBox<String> cmbProvinciaDivorciada;
    private javax.swing.JComboBox<String> cmbProvinciaDivorciado;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton44;
    private javax.swing.JRadioButton jRadioButtonEcuatorianoH;
    private javax.swing.JRadioButton jRadioButtonEcuatorianoM;
    private javax.swing.JRadioButton jRadioButtonExtrangeroM;
    private javax.swing.JRadioButton jRadioButtonExtranjeroH;
    private javax.swing.JRadioButton jRadioButtonLeerEscribirNO;
    private javax.swing.JRadioButton jRadioButtonLeerEscribirSI;
    private javax.swing.JRadioButton jRadioButtonLeerEscribirSIM;
    private javax.swing.JRadioButton jRadioButtonNoBienes;
    private javax.swing.JRadioButton jRadioButtonSiBienes;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner jSpinnerAniosMatrimonio;
    private javax.swing.JSpinner jSpinnerEdadDivorciada;
    private javax.swing.JSpinner jSpinnerEdadDivorciado;
    private javax.swing.JSpinner jSpinnerFechaInscripcion;
    private javax.swing.JSpinner jSpinnernumeroHijoDivorciada;
    private javax.swing.JSpinner jSpinnernumeroHijoDivorciado;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblLogoRegistroCivil;
    private javax.swing.JLabel lblNumFormulario;
    private com.toedter.calendar.JMonthChooser mesInscripcion;
    private com.toedter.calendar.JMonthChooser mesMatrimonio;
    private com.toedter.calendar.JMonthChooser mesNacimientoDivorciada;
    private com.toedter.calendar.JMonthChooser mesNacimientoDivorciado;
    private javax.swing.JPanel panel1;
    private javax.swing.JPanel panel2;
    private javax.swing.JPanel panel3;
    private javax.swing.JPanel panel4;
    private javax.swing.JPanel panel5;
    private javax.swing.JPanel panel6;
    private javax.swing.JPanel panel7;
    private javax.swing.JPanel panel9;
    private javax.swing.JTextField txtActaInscripcion;
    private javax.swing.JTextField txtCedulaDivorciada;
    private javax.swing.JTextField txtCedulaDivorciado;
    private javax.swing.JTextField txtCedulaFuncionarioRC;
    private javax.swing.JTextField txtCodCriticoCodifica;
    private javax.swing.JTextField txtCodPaisH;
    private javax.swing.JTextField txtCodPaisM;
    private javax.swing.JTextField txtDPAHom;
    private javax.swing.JTextField txtDPAMujer;
    private javax.swing.JTextField txtInecForm;
    private javax.swing.JTextField txtLocalidadHom;
    private javax.swing.JTextField txtLocalidadMujer;
    private javax.swing.JTextField txtNombDivorciada;
    private javax.swing.JTextField txtNombDivorciado;
    private javax.swing.JTextField txtNombrePaisH;
    private javax.swing.JTextField txtNombrePaisM;
    private javax.swing.JTextField txtNunOficina;
    private javax.swing.JTextField txtObservaciones;
    private javax.swing.JTextField txtnombOfiRC;
    // End of variables declaration//GEN-END:variables
}
